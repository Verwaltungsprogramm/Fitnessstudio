namespace MaterialDesignThemes.Wpf.Transitions
{
    public enum TransitionerSlideState
    {        
        None,
        Current,
        Previous,
    }
}